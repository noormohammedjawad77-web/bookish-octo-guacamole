package xyz.stark.areareset;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;

/**
 * %areareset_time_<name>%     -> 1m 6s
 * %areareset_seconds_<name>%  -> 66
 */
public class AreaPlaceholders extends PlaceholderExpansion {

    private final AreaReset plugin;

    public AreaPlaceholders(AreaReset plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "areareset";
    }

    @Override
    public @NotNull String getAuthor() {
        return "STARK";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        String p = params.toLowerCase();
        boolean raw;
        String name;
        if (p.startsWith("time_")) {
            raw = false;
            name = p.substring(5);
        } else if (p.startsWith("seconds_")) {
            raw = true;
            name = p.substring(8);
        } else {
            return null;
        }
        Area a = plugin.getArea(name);
        if (a == null) return "N/A";
        if (a.busy) return raw ? "0" : "Resetting";
        int s = Math.max(0, a.secondsLeft);
        return raw ? String.valueOf(s) : format(s);
    }

    static String format(int total) {
        int h = total / 3600;
        int m = (total % 3600) / 60;
        int s = total % 60;
        if (h > 0) return h + "h " + m + "m " + s + "s";
        if (m > 0) return m + "m " + s + "s";
        return s + "s";
    }
}
