package xyz.stark.areareset;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.ChunkSnapshot;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;

import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class Area {

    public final String name;
    public final String worldName;
    public final int minX, minY, minZ, maxX, maxY, maxZ;
    public int minutes;
    public int secondsLeft;
    public boolean busy = false;
    /** If not null, every player inside the area is moved to this Y at each reset. */
    public Integer resetY = null;

    private String[] paletteStr;
    private BlockData[] palette;
    private int[] data;
    private Map<Integer, byte[][]> containers = new HashMap<>();

    public Area(String name, String worldName, int x1, int y1, int z1, int x2, int y2, int z2, int minutes) {
        this.name = name;
        this.worldName = worldName;
        this.minX = Math.min(x1, x2);
        this.minY = Math.min(y1, y2);
        this.minZ = Math.min(z1, z2);
        this.maxX = Math.max(x1, x2);
        this.maxY = Math.max(y1, y2);
        this.maxZ = Math.max(z1, z2);
        this.minutes = minutes;
        this.secondsLeft = minutes * 60;
    }

    public int sizeX() { return maxX - minX + 1; }
    public int sizeY() { return maxY - minY + 1; }
    public int sizeZ() { return maxZ - minZ + 1; }
    public long volume() { return (long) sizeX() * sizeY() * sizeZ(); }
    public boolean hasSnapshot() { return data != null; }

    public boolean contains(Location l) {
        if (l.getWorld() == null || !l.getWorld().getName().equals(worldName)) return false;
        int x = l.getBlockX(), y = l.getBlockY(), z = l.getBlockZ();
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    private int index(int x, int y, int z) {
        return (y - minY) * sizeX() * sizeZ() + (z - minZ) * sizeX() + (x - minX);
    }

    private int[] coords(int i) {
        int sx = sizeX(), sz = sizeZ();
        return new int[]{minX + i % sx, minY + i / (sx * sz), minZ + (i / sx) % sz};
    }

    /** All chunk columns (cx, cz) that overlap the area. */
    private List<int[]> chunkList() {
        List<int[]> list = new ArrayList<>();
        for (int cx = minX >> 4; cx <= maxX >> 4; cx++) {
            for (int cz = minZ >> 4; cz <= maxZ >> 4; cz++) {
                list.add(new int[]{cx, cz});
            }
        }
        return list;
    }

    // ------------------------------------------------------------ capture

    /**
     * Saves the current look of the area. Chunks are snapshotted a few per tick on the main thread,
     * the heavy block scanning happens on async threads.
     */
    public void capture(AreaReset plugin, Runnable done) {
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            done.run();
            return;
        }
        busy = true;
        final int total = (int) volume();
        final int[] newData = new int[total];
        final ConcurrentHashMap<BlockData, Integer> ids = new ConcurrentHashMap<>();
        final AtomicInteger counter = new AtomicInteger();
        final Map<Integer, byte[][]> newContainers = new HashMap<>();
        final List<int[]> chunks = chunkList();
        final AtomicInteger pending = new AtomicInteger();
        final Area self = this;

        new BukkitRunnable() {
            int next = 0;

            @Override
            public void run() {
                int n = 0;
                while (next < chunks.size() && n < plugin.getChunksPerTick()) {
                    int[] cc = chunks.get(next++);
                    n++;
                    Chunk chunk = world.getChunkAt(cc[0], cc[1]);
                    final ChunkSnapshot snap = chunk.getChunkSnapshot(false, false, false);

                    // containers (chests, barrels, hoppers...) need the main thread
                    for (BlockState st : chunk.getTileEntities()) {
                        if (!(st instanceof Container cont)) continue;
                        int x = st.getX(), y = st.getY(), z = st.getZ();
                        if (x < minX || x > maxX || y < minY || y > maxY || z < minZ || z > maxZ) continue;
                        ItemStack[] items = cont.getSnapshotInventory().getContents();
                        byte[][] arr = new byte[items.length][];
                        for (int k = 0; k < items.length; k++) {
                            ItemStack it = items[k];
                            arr[k] = (it == null || it.getType().isAir()) ? new byte[0] : it.serializeAsBytes();
                        }
                        newContainers.put(index(x, y, z), arr);
                    }

                    pending.incrementAndGet();
                    Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                        try {
                            fillFromSnapshot(snap, cc[0], cc[1], newData, ids, counter);
                        } finally {
                            pending.decrementAndGet();
                        }
                    });
                }

                if (next >= chunks.size() && pending.get() == 0) {
                    cancel();
                    String[] ps = new String[counter.get()];
                    BlockData[] pal = new BlockData[counter.get()];
                    for (Map.Entry<BlockData, Integer> e : ids.entrySet()) {
                        pal[e.getValue()] = e.getKey();
                        ps[e.getValue()] = e.getKey().getAsString();
                    }
                    self.paletteStr = ps;
                    self.palette = pal;
                    self.data = newData;
                    self.containers = newContainers;
                    self.busy = false;
                    done.run();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    /** Runs async. */
    private void fillFromSnapshot(ChunkSnapshot snap, int cx, int cz, int[] out,
                                  ConcurrentHashMap<BlockData, Integer> ids, AtomicInteger counter) {
        int x0 = Math.max(minX, cx << 4), x1 = Math.min(maxX, (cx << 4) + 15);
        int z0 = Math.max(minZ, cz << 4), z1 = Math.min(maxZ, (cz << 4) + 15);
        for (int y = minY; y <= maxY; y++) {
            for (int z = z0; z <= z1; z++) {
                for (int x = x0; x <= x1; x++) {
                    BlockData bd = snap.getBlockData(x & 15, y, z & 15);
                    Integer id = ids.get(bd);
                    if (id == null) id = ids.computeIfAbsent(bd, k -> counter.getAndIncrement());
                    out[index(x, y, z)] = id;
                }
            }
        }
    }

    // ------------------------------------------------------------ reset

    /**
     * Restores the area. The comparison with the saved snapshot runs on async threads,
     * the main thread only changes the blocks that are actually different, within a time budget per tick.
     */
    public void reset(AreaReset plugin, Runnable done) {
        World world = Bukkit.getWorld(worldName);
        if (world == null || data == null) {
            done.run();
            return;
        }
        busy = true;

        // remove dropped items / xp / arrows inside the area
        BoundingBox box = new BoundingBox(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1);
        for (Entity e : world.getNearbyEntities(box)) {
            if (e instanceof Item || e instanceof ExperienceOrb || e instanceof Projectile) e.remove();
        }

        final List<int[]> chunks = chunkList();
        final ConcurrentLinkedQueue<int[]> queue = new ConcurrentLinkedQueue<>();
        final AtomicInteger pending = new AtomicInteger();
        final long budgetNanos = plugin.getMsBudget() * 1_000_000L;
        final int sx = sizeX(), sz = sizeZ();

        new BukkitRunnable() {
            int next = 0;
            int[] cur = null;
            int curPos = 0;

            @Override
            public void run() {
                // 1) snapshot a few chunks and send them to async threads for comparing
                int n = 0;
                while (next < chunks.size() && n < plugin.getChunksPerTick()) {
                    int[] cc = chunks.get(next++);
                    n++;
                    final ChunkSnapshot snap = world.getChunkAt(cc[0], cc[1]).getChunkSnapshot(false, false, false);
                    pending.incrementAndGet();
                    Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                        try {
                            queue.add(diff(snap, cc[0], cc[1]));
                        } finally {
                            pending.decrementAndGet();
                        }
                    });
                }

                // 2) apply the differences, but never use more than the time budget
                long deadline = System.nanoTime() + budgetNanos;
                int count = 0;
                outer:
                while (true) {
                    if (cur == null) {
                        cur = queue.poll();
                        if (cur == null) break;
                        curPos = 0;
                    }
                    while (curPos < cur.length) {
                        int i = cur[curPos++];
                        int x = minX + i % sx;
                        int y = minY + i / (sx * sz);
                        int z = minZ + (i / sx) % sz;
                        world.getBlockAt(x, y, z).setBlockData(palette[data[i]], false);
                        if ((++count & 127) == 0 && System.nanoTime() > deadline) break outer;
                    }
                    cur = null;
                }

                if (next >= chunks.size() && pending.get() == 0 && cur == null && queue.isEmpty()) {
                    cancel();
                    restoreContainers(world);
                    moveToResetY(world);
                    rescuePlayers(world);
                    busy = false;
                    done.run();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    /** Runs async: returns the indices of the blocks in this chunk that differ from the snapshot. */
    private int[] diff(ChunkSnapshot snap, int cx, int cz) {
        int x0 = Math.max(minX, cx << 4), x1 = Math.min(maxX, (cx << 4) + 15);
        int z0 = Math.max(minZ, cz << 4), z1 = Math.min(maxZ, (cz << 4) + 15);
        int[] out = new int[256];
        int n = 0;
        for (int y = minY; y <= maxY; y++) {
            for (int z = z0; z <= z1; z++) {
                for (int x = x0; x <= x1; x++) {
                    int idx = index(x, y, z);
                    BlockData have = snap.getBlockData(x & 15, y, z & 15);
                    if (!have.equals(palette[data[idx]])) {
                        if (n == out.length) out = Arrays.copyOf(out, n * 2);
                        out[n++] = idx;
                    }
                }
            }
        }
        return Arrays.copyOf(out, n);
    }

    private void restoreContainers(World world) {
        for (Map.Entry<Integer, byte[][]> e : containers.entrySet()) {
            int[] c = coords(e.getKey());
            Block b = world.getBlockAt(c[0], c[1], c[2]);
            if (!(b.getState() instanceof Container cont)) continue;
            Inventory inv = cont.getSnapshotInventory();
            byte[][] arr = e.getValue();
            inv.clear();
            for (int s = 0; s < arr.length && s < inv.getSize(); s++) {
                if (arr[s].length > 0) inv.setItem(s, ItemStack.deserializeBytes(arr[s]));
            }
            cont.update(true, false);
        }
    }

    private void moveToResetY(World world) {
        if (resetY == null) return;
        for (Player p : world.getPlayers()) {
            Location l = p.getLocation();
            if (!contains(l)) continue;
            p.teleport(new Location(world, l.getX(), resetY, l.getZ(), l.getYaw(), l.getPitch()));
        }
    }

    /** If a player ended up inside a solid block after the restore, move them up to a free spot. */
    private void rescuePlayers(World world) {
        for (Player p : world.getPlayers()) {
            Location l = p.getLocation();
            if (!contains(l)) continue;
            Block feet = l.getBlock();
            if (feet.isPassable() && feet.getRelative(0, 1, 0).isPassable()) continue;
            int y = feet.getY();
            int top = world.getMaxHeight() - 2;
            while (y < top) {
                Block f = world.getBlockAt(l.getBlockX(), y, l.getBlockZ());
                if (f.isPassable() && f.getRelative(0, 1, 0).isPassable()) break;
                y++;
            }
            p.teleport(new Location(world, l.getX(), y, l.getZ(), l.getYaw(), l.getPitch()));
        }
    }

    // ------------------------------------------------------------ disk

    public byte[] snapshotBytes() throws IOException {
        if (data == null) return null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(
                new BufferedOutputStream(new GZIPOutputStream(baos)))) {
            out.writeInt(sizeX());
            out.writeInt(sizeY());
            out.writeInt(sizeZ());
            out.writeInt(paletteStr.length);
            for (String s : paletteStr) out.writeUTF(s);
            out.writeInt(data.length);
            for (int v : data) out.writeInt(v);
            out.writeInt(containers.size());
            for (Map.Entry<Integer, byte[][]> e : containers.entrySet()) {
                out.writeInt(e.getKey());
                byte[][] arr = e.getValue();
                out.writeInt(arr.length);
                for (byte[] b : arr) {
                    out.writeInt(b.length);
                    out.write(b);
                }
            }
        }
        return baos.toByteArray();
    }

    public void loadSnapshot(InputStream raw) throws IOException {
        try (DataInputStream in = new DataInputStream(
                new BufferedInputStream(new GZIPInputStream(raw)))) {
            if (in.readInt() != sizeX() || in.readInt() != sizeY() || in.readInt() != sizeZ()) {
                throw new IOException("Snapshot size does not match the area");
            }
            int pn = in.readInt();
            String[] ps = new String[pn];
            BlockData[] pal = new BlockData[pn];
            for (int i = 0; i < pn; i++) {
                ps[i] = in.readUTF();
                try {
                    pal[i] = Bukkit.createBlockData(ps[i]);
                } catch (IllegalArgumentException ex) {
                    ps[i] = "minecraft:air";
                    pal[i] = Material.AIR.createBlockData();
                }
            }
            int n = in.readInt();
            int[] d = new int[n];
            for (int i = 0; i < n; i++) d[i] = in.readInt();
            int cn = in.readInt();
            Map<Integer, byte[][]> cm = new HashMap<>();
            for (int i = 0; i < cn; i++) {
                int idx = in.readInt();
                int len = in.readInt();
                byte[][] arr = new byte[len][];
                for (int k = 0; k < len; k++) {
                    int bl = in.readInt();
                    byte[] b = new byte[bl];
                    in.readFully(b);
                    arr[k] = b;
                }
                cm.put(idx, arr);
            }
            this.paletteStr = ps;
            this.palette = pal;
            this.data = d;
            this.containers = cm;
        }
    }
}
