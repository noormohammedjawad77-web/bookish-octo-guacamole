package xyz.stark.areareset;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

public class AreaReset extends JavaPlugin implements Listener, TabExecutor {

    private static final String PREFIX = "§b[AreaReset] §f";

    private final Map<String, Area> areas = new LinkedHashMap<>();
    private final Map<UUID, Location[]> selections = new HashMap<>();
    private NamespacedKey wandKey;
    private Database db;
    private int msBudget;
    private int chunksPerTick;
    private int maxBlocks;
    private List<Integer> warnSeconds;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        msBudget = Math.max(1, getConfig().getInt("max-ms-per-tick", 10));
        chunksPerTick = Math.max(1, getConfig().getInt("chunks-per-tick", 4));
        maxBlocks = getConfig().getInt("max-blocks", 8000000);
        warnSeconds = getConfig().getIntegerList("warn-seconds");
        wandKey = new NamespacedKey(this, "wand");

        if (!loadAreas()) {
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        getCommand("areareset").setExecutor(this);
        getCommand("areareset").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, this);

        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new AreaPlaceholders(this).register();
            getLogger().info("PlaceholderAPI found - %areareset_time_<name>% is available.");
        }

        Bukkit.getScheduler().runTaskTimer(this, this::tick, 20L, 20L);
    }

    @Override
    public void onDisable() {
        if (db != null) db.close();
    }

    public Area getArea(String name) { return areas.get(name.toLowerCase()); }
    public int getMsBudget() { return msBudget; }
    public int getChunksPerTick() { return chunksPerTick; }

    // ------------------------------------------------------------ timer

    private void tick() {
        for (Area a : areas.values()) {
            if (a.busy || !a.hasSnapshot()) continue;
            a.secondsLeft--;
            if (warnSeconds.contains(a.secondsLeft)) warnPlayers(a);
            if (a.secondsLeft <= 0) doReset(a);
        }
    }

    private void doReset(Area a) {
        a.reset(this, () -> {
            a.secondsLeft = a.minutes * 60;
            notifyPlayers(a, "✔ تم ارجاع المنطقة " + a.name, NamedTextColor.GREEN);
        });
    }

    private void warnPlayers(Area a) {
        notifyPlayers(a, "⚠ المنطقة " + a.name + " بترجع بعد " + a.secondsLeft + " ثانية", NamedTextColor.YELLOW);
    }

    private void notifyPlayers(Area a, String msg, NamedTextColor color) {
        org.bukkit.World w = Bukkit.getWorld(a.worldName);
        if (w == null) return;
        for (Player p : w.getPlayers()) {
            if (a.contains(p.getLocation())) p.sendActionBar(Component.text(msg, color));
        }
    }

    // ------------------------------------------------------------ wand

    private ItemStack makeWand() {
        ItemStack it = new ItemStack(Material.GOLDEN_AXE);
        ItemMeta m = it.getItemMeta();
        m.displayName(Component.text("عصا تحديد المنطقة", NamedTextColor.GOLD));
        m.lore(List.of(
                Component.text("كليك يسار = النقطة 1", NamedTextColor.GRAY),
                Component.text("كليك يمين = النقطة 2", NamedTextColor.GRAY)));
        m.getPersistentDataContainer().set(wandKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.LEFT_CLICK_BLOCK && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null || !it.hasItemMeta()) return;
        if (!it.getItemMeta().getPersistentDataContainer().has(wandKey, PersistentDataType.BYTE)) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("areareset.admin")) return;
        e.setCancelled(true);
        Location l = e.getClickedBlock().getLocation();
        Location[] sel = selections.computeIfAbsent(p.getUniqueId(), k -> new Location[2]);
        if (e.getAction() == Action.LEFT_CLICK_BLOCK) {
            sel[0] = l;
            msg(p, "النقطة 1 = " + fmt(l));
        } else {
            sel[1] = l;
            msg(p, "النقطة 2 = " + fmt(l));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        selections.remove(e.getPlayer().getUniqueId());
    }

    // ------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            help(s);
            return true;
        }
        String sub = a[0].toLowerCase();
        switch (sub) {
            case "wand" -> {
                if (!(s instanceof Player p)) { msg(s, "للاعبين فقط"); return true; }
                p.getInventory().addItem(makeWand());
                msg(s, "جبتلك العصا. كليك يسار = نقطة 1، كليك يمين = نقطة 2");
            }
            case "pos1", "pos2" -> {
                if (!(s instanceof Player p)) { msg(s, "للاعبين فقط"); return true; }
                Location[] sel = selections.computeIfAbsent(p.getUniqueId(), k -> new Location[2]);
                Location l = p.getLocation().getBlock().getLocation();
                sel[sub.equals("pos1") ? 0 : 1] = l;
                msg(s, (sub.equals("pos1") ? "النقطة 1" : "النقطة 2") + " = " + fmt(l));
            }
            case "create" -> create(s, a);
            case "time" -> {
                if (a.length < 3) { msg(s, "/ar time <اسم> <دقايق>"); return true; }
                Area ar = areas.get(a[1].toLowerCase());
                if (ar == null) { msg(s, "ما لقيت منطقة بهالاسم"); return true; }
                Integer min = parseMinutes(a[2]);
                if (min == null) { msg(s, "الدقايق لازم رقم اكبر من 0"); return true; }
                ar.minutes = min;
                ar.secondsLeft = min * 60;
                db.saveAreaAsync(ar);
                msg(s, "تم. المنطقة " + ar.name + " ترجع كل " + min + " دقيقة");
            }
            case "reset" -> {
                if (a.length < 2) { msg(s, "/ar reset <اسم>"); return true; }
                Area ar = areas.get(a[1].toLowerCase());
                if (ar == null) { msg(s, "ما لقيت منطقة بهالاسم"); return true; }
                if (ar.busy || !ar.hasSnapshot()) { msg(s, "المنطقة مشغولة او ما فيها نسخة محفوظة"); return true; }
                msg(s, "جاري ارجاع المنطقة...");
                ar.reset(this, () -> {
                    ar.secondsLeft = ar.minutes * 60;
                    msg(s, "✔ تم ارجاع المنطقة " + ar.name);
                });
            }
            case "update" -> {
                if (a.length < 2) { msg(s, "/ar update <اسم>"); return true; }
                Area ar = areas.get(a[1].toLowerCase());
                if (ar == null) { msg(s, "ما لقيت منطقة بهالاسم"); return true; }
                if (ar.busy) { msg(s, "المنطقة مشغولة"); return true; }
                msg(s, "جاري حفظ الشكل الحالي للمنطقة...");
                ar.capture(this, () -> {
                    ar.secondsLeft = ar.minutes * 60;
                    db.saveSnapshotAsync(ar);
                    msg(s, "✔ تم حفظ الشكل الجديد للمنطقة " + ar.name);
                });
            }
            case "delete" -> {
                if (a.length < 2) { msg(s, "/ar delete <اسم>"); return true; }
                Area ar = areas.get(a[1].toLowerCase());
                if (ar == null) { msg(s, "ما لقيت منطقة بهالاسم"); return true; }
                if (ar.busy) { msg(s, "المنطقة مشغولة، جرب بعد شوي"); return true; }
                areas.remove(ar.name);
                db.deleteAreaAsync(ar.name);
                msg(s, "تم حذف المنطقة " + ar.name);
            }
            case "y" -> {
                if (a.length < 3) { msg(s, "/ar y <اسم> <ارتفاع Y>"); return true; }
                Area ar = areas.get(a[1].toLowerCase());
                if (ar == null) { msg(s, "ما لقيت منطقة بهالاسم"); return true; }
                int newY;
                try {
                    newY = Integer.parseInt(a[2]);
                } catch (NumberFormatException ex) {
                    msg(s, "الارتفاع لازم رقم");
                    return true;
                }
                org.bukkit.World w = Bukkit.getWorld(ar.worldName);
                if (w == null) { msg(s, "العالم غير موجود"); return true; }
                if (newY < w.getMinHeight() || newY >= w.getMaxHeight()) {
                    msg(s, "الارتفاع لازم بين " + w.getMinHeight() + " و " + (w.getMaxHeight() - 1));
                    return true;
                }
                int moved = 0;
                for (Player p : w.getPlayers()) {
                    Location l = p.getLocation();
                    if (!ar.contains(l)) continue;
                    p.teleport(new Location(w, l.getX(), newY, l.getZ(), l.getYaw(), l.getPitch()));
                    moved++;
                }
                msg(s, "✔ تم نقل " + moved + " لاعب الى Y=" + newY);
            }
            case "resety" -> {
                if (a.length < 3) { msg(s, "/ar resety <اسم> <Y | off>"); return true; }
                Area ar = areas.get(a[1].toLowerCase());
                if (ar == null) { msg(s, "ما لقيت منطقة بهالاسم"); return true; }
                if (a[2].equalsIgnoreCase("off")) {
                    ar.resetY = null;
                    db.saveAreaAsync(ar);
                    msg(s, "تم ايقاف النقل التلقائي مع الريست");
                    return true;
                }
                int newY;
                try {
                    newY = Integer.parseInt(a[2]);
                } catch (NumberFormatException ex) {
                    msg(s, "الارتفاع لازم رقم او off");
                    return true;
                }
                org.bukkit.World w = Bukkit.getWorld(ar.worldName);
                if (w != null && (newY < w.getMinHeight() || newY >= w.getMaxHeight())) {
                    msg(s, "الارتفاع لازم بين " + w.getMinHeight() + " و " + (w.getMaxHeight() - 1));
                    return true;
                }
                ar.resetY = newY;
                db.saveAreaAsync(ar);
                msg(s, "✔ مع كل ريست للمنطقة " + ar.name + " ينقل اللاعبين اللي داخلها الى Y=" + newY);
            }
            case "list" -> {
                if (areas.isEmpty()) { msg(s, "ما في مناطق"); return true; }
                for (Area ar : areas.values()) {
                    msg(s, "§e" + ar.name + " §7| " + ar.worldName + " | " + ar.sizeX() + "x" + ar.sizeY() + "x" + ar.sizeZ()
                            + " | كل " + ar.minutes + " دقيقة | باقي " + ar.secondsLeft + " ثانية"
                            + (ar.resetY != null ? " | نقل Y=" + ar.resetY : "")
                            + (ar.busy ? " | §cمشغولة" : ""));
                }
            }
            default -> help(s);
        }
        return true;
    }

    private void create(CommandSender s, String[] a) {
        if (!(s instanceof Player p)) { msg(s, "للاعبين فقط"); return; }
        if (a.length < 3) { msg(s, "/ar create <اسم> <دقايق>"); return; }
        String name = a[1].toLowerCase();
        if (!name.matches("[a-z0-9_-]+")) { msg(s, "الاسم لازم انجليزي (حروف/ارقام/_/-)"); return; }
        if (areas.containsKey(name)) { msg(s, "فيه منطقة بنفس الاسم"); return; }
        Integer min = parseMinutes(a[2]);
        if (min == null) { msg(s, "الدقايق لازم رقم اكبر من 0"); return; }
        Location[] sel = selections.get(p.getUniqueId());
        if (sel == null || sel[0] == null || sel[1] == null) { msg(s, "حدد النقطتين اول (/ar wand)"); return; }
        if (!Objects.equals(sel[0].getWorld(), sel[1].getWorld())) { msg(s, "النقطتين لازم بنفس العالم"); return; }

        Area ar = new Area(name, sel[0].getWorld().getName(),
                sel[0].getBlockX(), sel[0].getBlockY(), sel[0].getBlockZ(),
                sel[1].getBlockX(), sel[1].getBlockY(), sel[1].getBlockZ(), min);
        if (ar.volume() > maxBlocks) {
            msg(s, "المنطقة كبيرة (" + ar.volume() + " بلوك). الحد " + maxBlocks);
            return;
        }
        areas.put(name, ar);
        msg(s, "جاري حفظ المنطقة (" + ar.volume() + " بلوك)...");
        ar.capture(this, () -> {
            ar.secondsLeft = ar.minutes * 60;
            db.saveAreaAsync(ar);
            db.saveSnapshotAsync(ar);
            msg(s, "✔ تم! المنطقة " + name + " بترجع كل " + min + " دقيقة");
        });
    }

    private Integer parseMinutes(String s) {
        try {
            int v = Integer.parseInt(s);
            return v > 0 ? v : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void help(CommandSender s) {
        msg(s, "§e/ar wand §7- عصا التحديد");
        msg(s, "§e/ar pos1 | pos2 §7- تحديد نقطة بمكانك");
        msg(s, "§e/ar create <اسم> <دقايق> §7- انشاء منطقة وحفظ شكلها");
        msg(s, "§e/ar time <اسم> <دقايق> §7- تغيير الوقت");
        msg(s, "§e/ar reset <اسم> §7- ارجاعها الحين");
        msg(s, "§e/ar update <اسم> §7- حفظ الشكل الحالي كنسخة جديدة");
        msg(s, "§e/ar y <اسم> <Y> §7- نقل كل اللاعبين داخل المنطقة لارتفاع Y (X وZ نفسهم)");
        msg(s, "§e/ar resety <اسم> <Y|off> §7- نقل اللاعبين لارتفاع Y تلقائي مع كل ريست");
        msg(s, "§e/ar delete <اسم> §7- حذف");
        msg(s, "§e/ar list §7- قائمة المناطق");
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String x : List.of("wand", "pos1", "pos2", "create", "time", "reset", "update", "y", "resety", "delete", "list")) {
                if (x.startsWith(a[0].toLowerCase())) out.add(x);
            }
        } else if (a.length == 2 && List.of("time", "reset", "update", "y", "resety", "delete").contains(a[0].toLowerCase())) {
            for (String n : areas.keySet()) {
                if (n.startsWith(a[1].toLowerCase())) out.add(n);
            }
        }
        return out;
    }

    // ------------------------------------------------------------ persistence

    private boolean loadAreas() {
        try {
            db = new Database(this);
            db.init();
            for (Area ar : db.loadAreas()) {
                byte[] snap = db.loadSnapshot(ar.name);
                if (snap != null) {
                    try {
                        ar.loadSnapshot(new ByteArrayInputStream(snap));
                    } catch (IOException e) {
                        getLogger().severe("Failed to load snapshot for " + ar.name + ": " + e.getMessage());
                    }
                } else {
                    getLogger().warning("No snapshot stored for area " + ar.name + " - run /ar update " + ar.name);
                }
                areas.put(ar.name, ar);
            }
            if (areas.isEmpty()) migrateLegacy();
        } catch (SQLException e) {
            getLogger().severe("Could not open the database: " + e.getMessage());
            return false;
        }
        getLogger().info("Loaded " + areas.size() + " area(s) from the database.");
        return true;
    }

    /** One-time import of the old areas.yml + snapshots/*.dat files into the database. */
    private void migrateLegacy() {
        File f = new File(getDataFolder(), "areas.yml");
        if (!f.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection sec = y.getConfigurationSection("areas");
        if (sec == null) return;
        for (String name : sec.getKeys(false)) {
            ConfigurationSection c = sec.getConfigurationSection(name);
            if (c == null) continue;
            Area ar = new Area(name, c.getString("world", "world"),
                    c.getInt("minX"), c.getInt("minY"), c.getInt("minZ"),
                    c.getInt("maxX"), c.getInt("maxY"), c.getInt("maxZ"),
                    Math.max(1, c.getInt("minutes", 20)));
            if (c.contains("resetY")) ar.resetY = c.getInt("resetY");
            File snap = new File(getDataFolder(), "snapshots/" + name + ".dat");
            if (snap.exists()) {
                try (FileInputStream in = new FileInputStream(snap)) {
                    ar.loadSnapshot(in);
                } catch (IOException e) {
                    getLogger().severe("Failed to import snapshot for " + name + ": " + e.getMessage());
                }
            }
            areas.put(name, ar);
            db.saveAreaAsync(ar);
            if (ar.hasSnapshot()) db.saveSnapshotAsync(ar);
        }
        f.renameTo(new File(getDataFolder(), "areas.yml.migrated"));
        getLogger().info("Imported " + areas.size() + " area(s) from the old files into the database.");
    }

    // ------------------------------------------------------------ helpers

    private void msg(CommandSender s, String m) {
        s.sendMessage(PREFIX + m);
    }

    private String fmt(Location l) {
        return l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ();
    }
}
