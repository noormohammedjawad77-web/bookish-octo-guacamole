package xyz.stark.areareset;

import org.bukkit.configuration.ConfigurationSection;

import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** SQLite (default) or MySQL storage. All writes go through one background thread, in order. */
public class Database {

    private final AreaReset plugin;
    private final String url;
    private final String user;
    private final String pass;
    private final boolean mysql;
    private Connection conn;

    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> new Thread(r, "AreaReset-DB"));

    public Database(AreaReset plugin) {
        this.plugin = plugin;
        ConfigurationSection c = plugin.getConfig().getConfigurationSection("database");
        String type = c == null ? "sqlite" : c.getString("type", "sqlite");
        this.mysql = type.equalsIgnoreCase("mysql");
        if (mysql) {
            String host = c.getString("host", "localhost");
            int port = c.getInt("port", 3306);
            String name = c.getString("name", "areareset");
            this.url = "jdbc:mysql://" + host + ":" + port + "/" + name
                    + "?useSSL=false&autoReconnect=true&characterEncoding=utf8";
            this.user = c.getString("user", "root");
            this.pass = c.getString("password", "");
            tryLoad("com.mysql.cj.jdbc.Driver");
        } else {
            plugin.getDataFolder().mkdirs();
            this.url = "jdbc:sqlite:" + new File(plugin.getDataFolder(), "areareset.db").getAbsolutePath();
            this.user = null;
            this.pass = null;
            tryLoad("org.sqlite.JDBC");
        }
    }

    private void tryLoad(String cls) {
        try {
            Class.forName(cls);
        } catch (ClassNotFoundException ignored) {
        }
    }

    private synchronized Connection conn() throws SQLException {
        if (conn == null || conn.isClosed() || !conn.isValid(2)) {
            conn = user == null ? DriverManager.getConnection(url) : DriverManager.getConnection(url, user, pass);
        }
        return conn;
    }

    public synchronized void init() throws SQLException {
        try (Statement st = conn().createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS areareset_areas ("
                    + "name VARCHAR(64) PRIMARY KEY, world VARCHAR(128) NOT NULL, "
                    + "min_x INT NOT NULL, min_y INT NOT NULL, min_z INT NOT NULL, "
                    + "max_x INT NOT NULL, max_y INT NOT NULL, max_z INT NOT NULL, "
                    + "minutes INT NOT NULL, reset_y INT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS areareset_snapshots ("
                    + "name VARCHAR(64) PRIMARY KEY, data LONGBLOB NOT NULL)");
        }
    }

    public synchronized List<Area> loadAreas() throws SQLException {
        List<Area> list = new ArrayList<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT name, world, min_x, min_y, min_z, max_x, max_y, max_z, minutes, reset_y "
                     + "FROM areareset_areas")) {
            while (rs.next()) {
                Area a = new Area(rs.getString(1), rs.getString(2),
                        rs.getInt(3), rs.getInt(4), rs.getInt(5),
                        rs.getInt(6), rs.getInt(7), rs.getInt(8), Math.max(1, rs.getInt(9)));
                int ry = rs.getInt(10);
                if (!rs.wasNull()) a.resetY = ry;
                list.add(a);
            }
        }
        return list;
    }

    public synchronized byte[] loadSnapshot(String name) throws SQLException {
        try (PreparedStatement ps = conn().prepareStatement("SELECT data FROM areareset_snapshots WHERE name = ?")) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getBytes(1) : null;
            }
        }
    }

    // ------------------------------------------------------------ async writes

    public void saveAreaAsync(Area a) {
        final String name = a.name, world = a.worldName;
        final int x1 = a.minX, y1 = a.minY, z1 = a.minZ, x2 = a.maxX, y2 = a.maxY, z2 = a.maxZ;
        final int minutes = a.minutes;
        final Integer resetY = a.resetY;
        submit(() -> {
            try (PreparedStatement ps = conn().prepareStatement(
                    "REPLACE INTO areareset_areas (name, world, min_x, min_y, min_z, max_x, max_y, max_z, minutes, reset_y) "
                            + "VALUES (?,?,?,?,?,?,?,?,?,?)")) {
                ps.setString(1, name);
                ps.setString(2, world);
                ps.setInt(3, x1);
                ps.setInt(4, y1);
                ps.setInt(5, z1);
                ps.setInt(6, x2);
                ps.setInt(7, y2);
                ps.setInt(8, z2);
                ps.setInt(9, minutes);
                if (resetY == null) ps.setNull(10, Types.INTEGER);
                else ps.setInt(10, resetY);
                ps.executeUpdate();
            }
        }, "save area " + name);
    }

    public void saveSnapshotAsync(Area a) {
        submit(() -> {
            byte[] bytes;
            try {
                bytes = a.snapshotBytes();
            } catch (IOException e) {
                throw new SQLException(e);
            }
            if (bytes == null) return;
            try (PreparedStatement ps = conn().prepareStatement(
                    "REPLACE INTO areareset_snapshots (name, data) VALUES (?, ?)")) {
                ps.setString(1, a.name);
                ps.setBytes(2, bytes);
                ps.executeUpdate();
            }
        }, "save snapshot " + a.name);
    }

    public void deleteAreaAsync(String name) {
        submit(() -> {
            try (PreparedStatement p1 = conn().prepareStatement("DELETE FROM areareset_areas WHERE name = ?");
                 PreparedStatement p2 = conn().prepareStatement("DELETE FROM areareset_snapshots WHERE name = ?")) {
                p1.setString(1, name);
                p1.executeUpdate();
                p2.setString(1, name);
                p2.executeUpdate();
            }
        }, "delete " + name);
    }

    private interface SqlTask {
        void run() throws SQLException;
    }

    private void submit(SqlTask task, String what) {
        try {
            exec.execute(() -> {
                try {
                    synchronized (Database.this) {
                        task.run();
                    }
                } catch (SQLException e) {
                    plugin.getLogger().severe("Database error (" + what + "): " + e.getMessage());
                }
            });
        } catch (java.util.concurrent.RejectedExecutionException ignored) {
        }
    }

    public void close() {
        exec.shutdown();
        try {
            exec.awaitTermination(30, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
        synchronized (this) {
            try {
                if (conn != null) conn.close();
            } catch (SQLException ignored) {
            }
        }
    }
}
